package models;

public enum ExcluidoStatus {
    ATIVADO, DESATIVADO
}
