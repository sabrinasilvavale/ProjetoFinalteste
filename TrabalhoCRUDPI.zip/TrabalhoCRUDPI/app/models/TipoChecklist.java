package models;

public enum TipoChecklist {
    SAIDA, CHEGADA
    
}
